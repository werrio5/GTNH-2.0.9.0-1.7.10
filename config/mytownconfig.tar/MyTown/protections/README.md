# MyTown2-Protections
All the protection files updated to the latest version for the MyTown2's protection system.

If one of the mod does not have a protection make an issue on this repository.
Make sure to provide information about what exactly needs to be protected (ex. for Buildcraft mod the Quarry). The resposability is yours to tell us exactly what you need to be included in the protections.
